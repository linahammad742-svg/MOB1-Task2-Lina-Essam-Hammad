package com.example.hellotoast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {

    private int mCount = 0;
    private TextView mShowCount;
    private Button mCountButton;
    private Button mZeroButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mShowCount = findViewById(R.id.show_count);
        mCountButton = findViewById(R.id.button_count);
        mZeroButton = findViewById(R.id.button_zero);
    }

    public void showToast(View view) {
        Toast toast = Toast.makeText(this,
                R.string.button_label_toast,
                Toast.LENGTH_SHORT);
        toast.show();
    }

    public void countUp(View view) {
        mCount++;

        if (mShowCount != null) {
            mShowCount.setText(Integer.toString(mCount));
        }

        if (mCount % 2 == 1) {
            mCountButton.setBackgroundColor(Color.GREEN);
        } else {
            mCountButton.setBackgroundColor(Color.BLUE);
        }

        mZeroButton.setBackgroundColor(Color.rgb(255, 165, 0));
    }

    public void resetCount(View view) {
        mCount = 0;
        mShowCount.setText(Integer.toString(mCount));

        mZeroButton.setBackgroundColor(Color.GRAY);
        mCountButton.setBackgroundColor(Color.BLUE);
    }
}
